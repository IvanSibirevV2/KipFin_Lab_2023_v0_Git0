/* 
#1 – Введение в язык JS. Что к чему
#2 – Основные моменты при работе с JavaScript
document.write("JavaScript говорит привет!");
console.log("JavaScript говорит привет!");
console.error("JavaScript говорит привет!");
console.warn("JavaScript говорит привет!");

#3 – Вывод информации. Работа с консолью
var num;
num = 5;
var num = 5;
num = 7;
console.log("Переменная: " + num + ".");

#4 – Переменные и типы данных в JS
const num = 5;
console.log("Переменная: " + num + ".");
var number;
number = true;
number = "stroka";
var num_1 = 5;
var num_2 = "5";

#5 – Математические действия
var num_1 = 5;
var num_2 = 15;
var res = num_1 - num_2;
console.log("Вычитание: " + res);
console.log("Вычитание: " + (num_1 - num_2));
console.log("Сложение: " + (num_1 + num_2));
console.log("Деление: " + (num_1 % num_2));
console.log("Умножение: " + (num_1 * num_2));

var num_3 = 5;
num_3 = num_3 + 7;
console.log("Результат: " + num_3);

var num_3 = 5;
num_3++;
console.log("Результат: " + num_3);

var num_3 = 5;
num_3--;
console.log("Результат: " + num_3);

var str_1 = "12";
var str_2 = "2";
console.log("Результат: " + (str_1 + str_2));

var str_1 = 12;
var str_2 = "2";
console.log("Результат: " + (str_1 + str_2));

var str_1 = Number("12");
var str_2 = Number("2");
console.log("Результат: " + (str_1 + str_2));

console.log("Math " + Math.PI);
console.log("Math " + Math.E);
console.log("Math " + Math.min(4, 6, 8, 2, 0, 5, -8));
console.log("Math " + Math.max(4, 6, 8, 2, 0, 5, -8));

#6 – Условные операторы
var number = 15;
if(5 == 5) {
    console.log("ok");
}

var number = 15;
if(number == 5) {
    console.log("ok");
}

var number = 15;
if(number > 5) {
    console.log("ok");
}

var number = 15;
if(number == "15") {
    console.log("ok");
}

var number = 15;
if(number != 5) {
    console.log("ok");
}

var number = 15;
if(number != 15) {
    console.log("ok");
} else {
    console.log("else");
}

var number = 15;
if(number == 15) {
    console.log("ok");
} else {
    console.log("else");
}

var number = 15;
if(number == 5) {
    console.log("ok");
} else if (number < 10) {
    console.log("ok!");
} else if (number == 7) {
    console.log("7!");
} else if (number >= 15) {
    console.log(">=15!");
} else {
    console.log("else");
}

var number = 15;
var isHasHouse = true;
if(number == 5 || isHasHouse == true) {
    console.log("ok");
} else if (number < 10) {
    console.log("ok!");
} else if (number == 7) {
    console.log("7!");
} else if (number >= 15) {
    console.log(">=15!");
} else {
    console.log("else");
}

var number = 15;
var isHasHouse = true;
if(number == 5 && !isHasHouse) {
    console.log("ok");
} else if (number < 10) {
    console.log("ok!");
} else if (number == 7) {
    console.log("7!");
} else if (number >= 15) {
    console.log(">=15!");
} else {
    console.log("else");
}

var stroka = "word";
switch(stroka) {
    case "4": 
        console.log("Переменная со значением 4!");
        break;
    case "45":
        console.log("Переменная со значением 45!");
        break;
    case "word": 
        console.log("Переменная со значением word!");
        break;
    }

var stroka = "word23";
switch(stroka) {
    case "4": 
        console.log("Переменная со значением 4!");
        break;
    case "45":
        console.log("Переменная со значением 45!");
        break;
    case "word": 
        console.log("Переменная со значением word!");
        break;
    default:
        console.log("Default")
    }

#7 - Массивы данных. Одномерные и многомерные массивы
var arr = [5, true, "stroka", 5.7, 0, -100];
console.log(arr);

var arr = [5, true, "stroka", 5.7, 0, -100];
console.log(arr[0]);

var arr = [5, true, "stroka", 5.7, 0, -100];
arr[3] = "word";
console.log(arr[3]);

var arr = [5, true, "stroka", 5.7, 0, -100];
arr[3] = "word";
console.log(arr.length);

var matrix = [
    [4, 6, 8], ["stroka", 5.7], [0, -100]
];
matrix[1][0] = 90;
console.log(matrix);

#8 – Циклы в JavaScript. Операторы циклов
for(var i = 0; i < 10; i++)
{
    console.log(i);
}

for(var i = 1; i <= 10; i++)
{
    console.log(i);
}

for(var i = 100; i > 5; i /= 2)
{
    console.log(i);
}

var j = 1000;
while(j >= 100) {
    console.log(j);
    j -= 100;
}

var isHasCar = true;
while(isHasCar) {}

var x = 100;
do {
    console.log(x);
} while(x < 50);

var x = 0;
do {
    console.log(x);
    x++;
} while(x < 10);

for(var i = 10; i <= 20; i += 2) {
    console.log(i);
}

for(var i = 10; i <= 20; i += 2) {
    if (i > 15)
        break;
    console.log(i);
}

for(var i = 10; i <= 20; i++) {
    console.log(i);
}

for(var i = 10; i <= 20; i++) {
    if (i % 2 == 0)
    continue;
    console.log(i);
}

var arr = [5, 7, 3, 8, 9, 91]
for (var i = 0; i < arr.length; i++) {
    arr[i] *= 2;
    console.log("Элемент " + (i + 1) + ": " + arr[i]);
}

#9 – Всплывающие окна (alert, prompt, confirm)
alert("Какая хорошая погода!");
confirm("Вы сейчас дома?");
prompt("Скажите, сколько вам лет");

var data = confirm("Вы сейчас дома?");
if (data) {
    alert("Вы молодец!");
}

var data = prompt("Скажите, сколько вам лет");
console.log(data);

var person = null;
if (confirm("Вы точно уверены?")) {
    person = prompt("Введите имя")
    alert("Привет, " + person)
} else {
    alert("Вы нажали на отмену")
}

#10 – Функции в языке JavaScript
function info() {
    console.log("Привет");
    console.log("!");
}
info();

function info(word) {
    console.log(word + "!");
}
info("Hello");

function info(word) {
    console.log(word + "!");
}
function summa(a, b) {
    var res = a + b;
    info(res);
}
summa(5, 7);

function summa(arr) {
    var sum = 0;
    for(var i = 0; i < arr.lenght; i++)
    sum += arr[i];
    return sum;
}
var array = [6, 8, 1];
var res = summa(array);
console.log("Результат: " + res);

var num = 10;
function info() {
    var num = 20;
    console.log(num);
}

info();
console.log(num);

#11 – События и обработчик событий в JavaScript
function onClickButton() {
    alert('Вы нажали на меня');
}

var counter = 0;
function onClickButton() {
    counter++;
    console.log(counter);
}

var counter = 0;
function onClickButton(el) {
    counter++;
    el.innerHTML = "Вы нажали на кнопку: " + counter;
    console.log(counter);
}

var counter = 0;
function onClickButton(el) {
    counter++;
    el.innerHTML = "Вы нажали на кнопку: " + counter;
    console.log(el.name);
}

function onInput(el) {
    if(el.value == "Hello")
    alert("И тебе привет!");
    console.log(el.value);
}

function onClickButton(el) {
    counter++;
    el.innerHTML = "Вы нажали на кнопку: " + counter;
    el.style.background = "red";
    el.style.color = "blue";
    el.style.cssText = "border-radius: 5px; border: 0; font-size: 20px";
}
#12 – Управление HTML и обработка форм при помощи JS
var text = document.getElementById('text');
text.title = "New Text";
console.log(text.title);

text.style.color = "red";
text.style.backgroundColor = "blue";
text.innerHTML = "New<br>string";
document.getElementById('text').style.color = "white";

var spans = document.getElementsByClassName('simple-text');
for ( var i = 0 ; i < spans.length; i++) {
console.log(spans[i].innerHTML);
}

document.getElementById('main-form').addEventListener("submit", checkForm);
function checkForm(){
var el = document.getElementById('main-form');

var name = el.name.value;
var pass = el.pass.value;
var repass = el.repass.value;
var state = el.state.value;
var fail = "";

if (name == "" || pass == "" || state == "") {
    fail = "Заполните все поля!";
} else if(name.length <= 1 || name.length > 50){
    fail = "Введите корректное имя";
} else if( pass != repass){
    fail = "Пароли не совпадают";
} else if( pass.split("&").length > 1) {
    fail = "Некорректный пароль";
}

if (fail != "") {
    document.getElementById('error').innerHTML = fail;
    return false;
} else {
    alert("Все данные корректно заполнены");
    window.location = 'https://itproger.com/course/javascript/12';
    return false;
    }
}

#13 – Создание таймеров и интервалов
setInterval(my_func, 1000);
var counter = 0;
function my_func() {
    counter++;
    console.log("Counter: " + counter);
}

var counter = 0;
setInterval(function() {
    counter++;
    console.log("Прошло секунд: " + counter);
}, 1000);

setTimeout(function() {
    console.log("Timer is working!")
}, 2000)

#14 – Создание объектов. Встроенные функции
var date = new Date();
console.log(date.getDate());

var date = new Date();
date.setHours(23);
date.setMinutes(23);
console.log("Время: " + date.getHours() + ":" + date.getMinutes()); 

var arr = [5, 7, 8, 9];
console.log(arr.join("|||"));

var arr = [8, 90, 5, 7, 0, 8, 9];
console.log(arr.reverse());

var arr = [8, 90, 5, 7, 0, 8, 9];
var stroka = arr.reverse().join(", ");
console.log(stroka.split(", "));

class Person {
    constructor(name, age, happiness) {
        this.name = name;
        this.age = age;
        this.happiness = happiness;
    }

    info() {
        console.log("Человек: " + this.name, "Возраст: " + this.age)
    }
}

var alex = new Person('Alex', 45, true);
var bob = new Person('Bob', 25, false);
alex.info();
bob.info();
*/
class Person {
    constructor(name, age, happiness) {
        this.name = name;
        this.age = age;
        this.happiness = happiness;
    }

    info() {
        console.log("Человек: " + this.name, "Возраст: " + this.age)
    }
}

var alex = new Person('Alex', 45, true);
var bob = new Person('Bob', 25, false);
alex.info();
bob.info();