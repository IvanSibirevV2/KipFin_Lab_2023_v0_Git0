//document.write("Js says hello to u!")
//console.log("Js says hello to u!")
//console.info("Js says hello to u!")
//console.error("Js says hello to u!")
//console.warn("Js says hello to u!")

//var num = 5;
//num = 7;
//const num2 = 5;
//var bool1 = true;
//var string1 = "Переменная";
//console.log("Переменная: " + num + ".")

/* var num1 = 5;
var num2 = 15;
console.log("ВЫчитание: " + (num2 - num1))
var num3 = 5;
num3 += 7;
num3++;
var str1 = "12";
var str2 = "2";
var str3 = Number("12")
console.log("Результат: " + (str1 + str2))
console.log("Math: " + Math.PI); */

/* var num = 15;
var isHasHouse = true;
if(num == 5 && isHasHouse == true){
    console.log("OK!")
} else if(num == 15 || isHasHouse == true){
    console.log("Else OK!")
}
else {
    console.log("Else!")
} */

/* var stroka = "word";
switch (stroka) {
    case "4":
        console.log("Значение: 4");
        break;
    case "45":
        console.log("Значение: 45");
        break;
    case "word":
        console.log("Значение: word");
        break;
    default:
        console.log("Default");
} */

/* var arr = [5, true, "stroka", 5.7];
console.log(arr);
console.log(arr.length);
var matrix = [[4,6,8],["stroka",5.7], [0,-100]];
console.log(matrix); */

/* for ( var i = 10; i < 20; i++){
    if(i % 2 == 0)
    {
        continue;
    }
    console.log(i)
}
var j = 0;
while(j < 10) {
    j++;
}
var x = 0;
do {
    console.log(x);
} while (x < 10){
    x++;
}
var arr = [5,7,8,3, "stroka"];
for ( var i = 0 ; i < arr.length; i++){
    console.log(arr[i]);
} */

/* alert("Какая хорошая погода!");
var data = confirm("Вы сейчас дома?");
if ( data ) {
    alert("Отлично!");
}
var data2 = prompt("Сколько вам лет?");
console.log(data);

var person = null;
if(confirm("Вы уверенны?")) {
    person = prompt("Введите имя!");
    alert("Привет " + person)
} else {
    alert("Вы нажали на Отмена");
} */

/* function info(word) {
    console.log(word + "!");
    var num = 10;
    console.log(num);
}
function summ(a,b) {
    var res = a + b;
    info(res);
}
summ(5,7);
info();

var sum = 0;
function summArray(arr) {
    for (var i = 0; arr.length; i++) {
        sum += arr[i];
    }

    return sum;
}
var array = [5,8,3,9];
var summa = summArray(array);
console.log(summa); */

var counter = 0;
function onClickButton(el){
    counter++;
    el.innerHTML = "Вы нажали на кнопку: " + counter;
    console.log(el.onclick);
    el.style.background = "red";
}
function onMouseOver(el) {
    if(el == "Hello")
        alert("И тебе привет!");

    console.log(el.value);
}

var text = document.getElementById('text');
text.title = "New Text";
console.log(text.title);

text.style.color = "red";
text.style.backgroundColor = "blue";
text.innerHTML = "New<br>string";
document.getElementById('text').style.color = "white";

var spans = document.getElementsByClassName('simple-text');
for ( var i = 0 ; i < spans.length; i++) {
    console.log(spans[i].innerHTML);
}

document.getElementById('main-form').addEventListener("submit", checkForm);
function checkForm(){
    var el = document.getElementById('main-form');

    var name = el.name.value;
    var pass = el.pass.value;
    var repass = el.repass.value;
    var state = el.state.value;
    var fail = "";

    if (name == "" || pass == "" || state == "") {
        fail = "Заполните все поля!";
    } else if(name.length <= 1 || name.length > 50){
        fail = "Введите корректное имя";
    } else if( pass != repass){
        fail = "Пароли не совпадают";
    } else if( pass.split("&").length > 1) {
        fail = "Некорректный пароль";
    }

    if (fail != "") {
        document.getElementById('error').innerHTML = fail;
        return false;
    } else {
        alert("Все данные корректно заполнены");
        window.location = 'https://www.youtube.com/watch?v=1nzH6WCEonQ&list=PLDyJYA6aTY1kJIwbYHzGOuvSMNTfqksmk&index=13';
        return false;
    }
}

/* var id = setInterval(my_func, 1000);
var counter = 0;
function my_func(){
    counter++;
    console.log(counter)

    if ( counter == 3)
        clearInterval(id);
}

setTimeout(my_Func, 2000);
function my_Func() {
    console.log("Timer is working");
} */

var date = new Date();

date.setHours(23);
date.setMinutes(23);
console.log("Время: " + date.setHours() + ":" + date.setMinutes());

class Person {
    constructor(name, age, happiness) {
        this.name = name;
        this.age = age;
        this.happiness = happiness;
    }
    info(){
        console.log("Человке: " + this.name + "Возраст: " + this.age);
    }
}

var alex = new Person('Alex',45,true);
alex.info();