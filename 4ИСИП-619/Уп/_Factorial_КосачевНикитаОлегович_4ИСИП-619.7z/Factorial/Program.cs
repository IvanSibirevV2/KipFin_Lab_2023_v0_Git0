﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Factorial
{
    public class Schet
    {
        public string ToString() 
        {
            return this.Counter.ToString();
        }
        public System.UInt64 Counter = 0;
        public Schet UperSchet = null;
        public Schet DounSchet = null;
        public Schet Inc()
        {
            if (Counter == 9999999999999999999uL)
            { Counter = 0uL; if (this.UperSchet != null) this.UperSchet.Inc(); }
            else { Counter++; }
            return this;
        }
        public static Schet operator ++(Schet _Schet) { _Schet.Inc(); return _Schet; }
        public Schet Dec()
        {
            if (Counter == 0)
            { Counter = 9999999999999999999uL;
                if (this.DounSchet != null) this.DounSchet.Dec(); }
            else { Counter--; }
            return this;
        }
        public static Schet operator --(Schet _Schet)
        {
            _Schet.Dec(); return _Schet;
        }
    }
    public class MasarakSh:List<Schet>
    {
        public MasarakSh() 
        {
            this.Add( new Schet());
            this.Add(new Schet());
            this.Add(new Schet());
            this.Add(new Schet());
        }
        public string ToString_() 
        {
            return System.String.Join(".",this.Select(s => s.ToString()));
        }
        public MasarakSh Add_(Schet _Schet) 
        {
            this[this.Count-1].UperSchet = _Schet;
            _Schet.DounSchet = this[this.Count - 1];
            this.Add(_Schet);
            return this;
        }
        public MasarakSh Inc(){ this[0].Inc();return this;}
        public static MasarakSh operator ++(MasarakSh _MasarakSh){_MasarakSh.Dec(); return _MasarakSh;}
        public MasarakSh Dec() { this[0].Dec();return this;}
        public static MasarakSh operator --(MasarakSh _MasarakSh){_MasarakSh.Dec(); return _MasarakSh;}
        public MasarakSh Plus( MasarakSh _MasarakSh) 
        {
            while (_MasarakSh[0].Counter!=0) 
            {
                this.Inc();
                _MasarakSh.Dec();
            }
            return this;
        }
        public static MasarakSh operator +(MasarakSh _MasarakSh1, MasarakSh _MasarakSh2){return _MasarakSh1.Plus(_MasarakSh2);}
        public MasarakSh Minus(MasarakSh _MasarakSh)
        {
            while (_MasarakSh[0].Counter != 0)
            {
                this.Dec();
                _MasarakSh.Dec();
            }
            return this;
        }
        public static MasarakSh operator -(MasarakSh _MasarakSh1, MasarakSh _MasarakSh2){return _MasarakSh1.Minus(_MasarakSh2);}
        public static implicit operator MasarakSh(int qwe)
        {
            qwe = System.Math.Abs(qwe);
            MasarakSh _MasarakSh = new MasarakSh();
            while (qwe != 0)
            {
                _MasarakSh++;
                qwe--;
            }
            return _MasarakSh;
        }
        public MasarakSh Copy() 
        {
            MasarakSh _MasarakSh = new MasarakSh();
            this.ForEach(a => _MasarakSh.Add(a));
            return _MasarakSh;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            MasarakSh _MasarakSh = new MasarakSh();
            _MasarakSh= _MasarakSh+4;
            System.Console.WriteLine(_MasarakSh.ToString_());
            /*
            long double chislo = 1;
            for (int i = 500; i >0; i--)
            {
                chislo *= i;
                Console.WriteLine(chislo.ToString());

            }

            Console.WriteLine("-----------------------------------");

            Console.WriteLine(chislo.ToString());
            */
            Console.ReadLine();
        }
    }
}
